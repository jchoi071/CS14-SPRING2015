//  ====================== Description ======================
///
/// Name: Ji Hoon Choi
/// SID: 861160400
/// Date: 5/11/15
///
//  =========================================================

#include <iostream>
#include <utility>
#include <vector>
#include <array>
#include <list>
#include <forward_list>

using namespace std;

//overloaded << operator for outputting contents of pairs
template<typename C, typename D>
ostream& operator<<(ostream& os, const pair<C, D>& p)
{
    os << '(' << p.first << ", " << p.second << ')';
    return os;
}

//the selection sort itself
template<typename L>
void selectionsort(L &l)
{
    auto iter = l.begin();
    int numMoves = 0;
    
    //before sorting
    cout << "pre:  ";
    for (iter = l.begin(); iter != l.end(); ++iter)
    {
        cout << *iter << ' ';
    }
    cout << endl;
    
    //every loop increments the lower bound of the selection sort - anything
    //below the lower bound is sorted, and anything above the lower bound
    //is not sorted
    for (auto currentIter = l.begin(); currentIter != l.end(); ++currentIter)
    {
        bool found = false;
        auto least = currentIter;
        //iterate through container
        for (auto iter = currentIter; iter != l.end(); ++iter)
        {
            if (*iter < *least)
            {
                //if a value lower than the current lowest value is found then
                //the lower value is the new lowest value
                found = true;
                least = iter;
            }
        }
        if (found) //do not swap if smallest element remains the same
        {
            //swap lower bound of sorting with lowest value in the unsorted
            //part of the container
            swap(*currentIter, *least);
            //increment number of moves for later
            ++numMoves;
        }
    }
    
    //after sorting
    cout << "post: ";
    for (iter = l.begin(); iter != l.end(); ++iter)
    {
        cout << *iter << ' ';
    }
    cout << endl;
    
    //there are no object copies in this code
    //numMoves * 3 is neccessary because each swap equals 3 moves
    cout << "0 copies and " << numMoves * 3 << " moves" << endl; 
    cout << endl;
}

int main()
{
    //Vector
    
    vector<int> vectorTest(6);
    
    vectorTest.at(0) = 2;
    vectorTest.at(1) = 4;
    vectorTest.at(2) = 5;
    vectorTest.at(3) = 1;
    vectorTest.at(4) = 8;
    vectorTest.at(5) = 9;

    selectionsort(vectorTest);
    
    //Array
    
    array<int, 6> arrayTest = {2, 4, 5, 1, 8, 9};

    selectionsort(arrayTest);
    
    //Empty vector
    
    vector<int> emptyVector;
    
    selectionsort(emptyVector);

    //List
    
    list<int> listTest;
    
    listTest.push_back(99);
    listTest.push_back(6);
    listTest.push_back(99);
    listTest.push_back(25);
    listTest.push_back(36);
    listTest.push_back(224);
    listTest.push_back(12);
    listTest.push_back(723);
    listTest.push_back(777);
    
    list<int>::iterator iter;
    
    selectionsort(listTest);
    
    list< pair<int, int> > pairTest;
    pairTest.push_back(pair<int, int>(1, 2));
    pairTest.push_back(pair<int, int>(3, -1));
    pairTest.push_back(pair<int, int>(-1, 3));
    pairTest.push_back(pair<int, int>(0, 0));
    pairTest.push_back(pair<int, int>(2, 3));
    pairTest.push_back(pair<int, int>(1, 2));
    pairTest.push_back(pair<int, int>(1, -2));
    pairTest.push_back(pair<int, int>(8, 10));
    
    selectionsort(pairTest);
    
    forward_list< pair<int, int> > pairTest2;
    pairTest2.push_front(pair<int, int>(10, 2));
    pairTest2.push_front(pair<int, int>(0, 0));
    pairTest2.push_front(pair<int, int>(5, -5));
    pairTest2.push_front(pair<int, int>(5, 5));
    pairTest2.push_front(pair<int, int>(10, 2));
    pairTest2.push_front(pair<int, int>(0, 0));
    pairTest2.push_front(pair<int, int>(1, 1));
    pairTest2.push_front(pair<int, int>(1, 1));
    pairTest2.push_front(pair<int, int>(-8, 0));
    pairTest2.push_front(pair<int, int>(-3, -1));
    pairTest2.push_front(pair<int, int>(10, 2));
    
    selectionsort(pairTest2);
}